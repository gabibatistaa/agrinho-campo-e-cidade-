
let truck;
let items = [];
let score = 0;

function setup() {
  createCanvas(800, 400);
  truck = new Truck();
  frameRate(60);
}

function draw() {
  background(220);

  // Divisória entre campo e cidade
  stroke(0);
  line(width / 2, 0, width / 2, height);
  noStroke();

  // Labels
  textSize(16);
  fill(0);
  text("🌾 Campo", 50, 30);
  text("🏙️ Cidade", width - 120, 30);
  text("Pontuação: " + score, width / 2 - 50, 30);

  truck.update();
  truck.show();

  // Atualiza e desenha itens
  for (let i = items.length - 1; i >= 0; i--) {
    items[i].show();
    if (truck.collect(items[i])) {
      items.splice(i, 1);
    }
  }

  // Gera novos itens
  if (frameCount % 120 === 0) {
    items.push(new Item());
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) truck.dir(-1, 0);
  if (keyCode === RIGHT_ARROW) truck.dir(1, 0);
  if (keyCode === UP_ARROW) truck.dir(0, -1);
  if (keyCode === DOWN_ARROW) truck.dir(0, 1);
}

// Classe caminhão
class Truck {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 40;
    this.speed = 3;
    this.carrying = null;
    this.xdir = 0;
    this.ydir = 0;
  }

  dir(x, y) {
    this.xdir = x;
    this.ydir = y;
  }

  update() {
    this.x += this.xdir * this.speed;
    this.y += this.ydir * this.speed;

    // Limites da tela
    this.x = constrain(this.x, 0, width - this.size);
    this.y = constrain(this.y, 0, height - this.size);

    // Entrega
    if (this.carrying) {
      if (this.x < 10 && this.carrying.type === "tech") {
        score += 1;
        this.carrying = null;
      } else if (this.x > width - 50 && this.carrying.type === "food") {
        score += 1;
        this.carrying = null;
      } else if (this.x < 10 || this.x > width - 50) {
        score -= 1;
        this.carrying = null;
      }
    }
  }

  collect(item) {
    let d = dist(this.x, this.y, item.x, item.y);
    if (d < this.size / 2 + item.size / 2 && !this.carrying) {
      this.carrying = item;
      return true;
    }
    return false;
  }

  show() {
    fill(150, 100, 50);
    rect(this.x, this.y, this.size, this.size);
    if (this.carrying) {
      fill(this.carrying.color);
      ellipse(this.x + this.size / 2, this.y - 10, 15);
    }
  }
}

// Classe dos itens
class Item {
  constructor() {
    this.size = 20;
    this.type = random(["food", "tech"]);
    if (this.type === "food") {
      this.x = random(20, width / 2 - 40);
      this.color = color(0, 200, 0);
    } else {
      this.x = random(width / 2 + 20, width - 40);
      this.color = color(0, 100, 255);
    }
    this.y = random(40, height - 40);
  }

  show() {
    fill(this.color);
    ellipse(this.x, this.y, this.size);
  }
}
